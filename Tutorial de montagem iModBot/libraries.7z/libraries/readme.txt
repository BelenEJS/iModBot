Para informação sobre a instalação de bibliotecas, veja: http://www.arduino.cc/en/Guide/Libraries
